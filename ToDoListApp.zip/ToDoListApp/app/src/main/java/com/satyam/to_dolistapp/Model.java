package com.satyam.to_dolistapp;

public class Model {
    String task;

    public Model(String task){
        this.task=task;
    }


}
