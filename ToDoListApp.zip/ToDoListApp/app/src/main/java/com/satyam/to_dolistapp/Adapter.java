package com.satyam.to_dolistapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    Context context;
    ArrayList<Model>arrayList;
    Adapter(Context context, ArrayList<Model>arrayList){
        this.context=context;
        this.arrayList=arrayList;
    }

    @NonNull
    @Override

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view=LayoutInflater.from(context).inflate(R.layout.tasklayout, parent, false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {

        holder.checkBox.setText(arrayList.get(position).task);
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog= new Dialog(context);
                dialog.setContentView(R.layout.newtask);

                Button newTaskButton=dialog.findViewById(R.id.newTaskButton);
                newTaskButton.setText("Update");
                EditText newTaskText = dialog.findViewById(R.id.newTaskText);

                newTaskButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            String text="";
                            if (!newTaskText.getText().toString().equals("")){
                                text = newTaskText.getText().toString();

                            }else {
                                Toast.makeText(context, "Please Add the Text", Toast.LENGTH_SHORT).show();
                            }

                        arrayList.set(position,new Model(text));
                        notifyItemChanged(position);
                        dialog.dismiss();



                    }
                    });
                dialog.show();

            }
        });

        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder alertDialog= new AlertDialog.Builder(context).setTitle("Delete Item")
                        .setMessage("Are you sure you want to delete this item ?")
                        .setIcon(R.drawable.baseline_delete_24)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                arrayList.remove(position);
                                notifyItemRemoved(position);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });

                alertDialog.show();

                return true;
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
         CardView cardView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox =itemView.findViewById(R.id.checkBox);
            cardView = itemView.findViewById(R.id.cardView);
        }
    }
}
