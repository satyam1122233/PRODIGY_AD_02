package com.satyam.to_dolistapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Model>arrayList=new ArrayList<>();
    RecyclerView taskrecyclerView;
    FloatingActionButton fabtn;


    Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskrecyclerView= findViewById(R.id.taskRecyclerView);
        taskrecyclerView.setLayoutManager(new LinearLayoutManager(this));

        fabtn=findViewById(R.id.fab);


        fabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Dialog dialog=new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.newtask);

                EditText newTaskText = dialog.findViewById(R.id.newTaskText);
                Button newTaskButton=dialog.findViewById(R.id.newTaskButton);

                adapter = new Adapter(MainActivity.this, arrayList);
                taskrecyclerView.setAdapter(adapter);

                newTaskButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String text="";
                        if (!newTaskText.getText().toString().equals("")){
                             text = newTaskText.getText().toString();
                            arrayList.add(new Model(text));

                                adapter.notifyItemInserted(arrayList.size() - 1);
                                taskrecyclerView.scrollToPosition(arrayList.size() - 1);

                            dialog.dismiss();

                        }else {
                            Toast.makeText(MainActivity.this, "Please Add the Text", Toast.LENGTH_SHORT).show();
                        }



                    }
                });


                dialog.show();


            }
        });
    }
}